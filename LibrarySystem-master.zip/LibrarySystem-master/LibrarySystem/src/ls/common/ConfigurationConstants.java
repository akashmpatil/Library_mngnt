package ls.common;

public class ConfigurationConstants {

	public interface LabelMessages {
		public final static String OPERATION_DONE_SUCCESSFULLY = "Operation Done Successfully.";
		public final static String OPERATION_FAILED = "Operation Failed.";
	}
}
