package ls.dataaccess;

import java.io.Serializable;

public enum Auth implements Serializable {
	LIBRARIAN, ADMIN, BOTH;
}
