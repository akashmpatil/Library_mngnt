# Library-System(MPP Project)
A simple library management system created for fulfillment of Modern Programming Practices (JAVA) Course

# Technology Used:
- Java SE 8
- Java FX
